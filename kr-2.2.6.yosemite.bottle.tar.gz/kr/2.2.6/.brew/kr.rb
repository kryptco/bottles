class Kr < Formula
  desc "Kryptonite command line client, daemon, and SSH integration"
  homepage "https://krypt.co"
  url "https://github.com/kryptco/kr.git", :tag => "2.2.5"

  devel do
	  url "https://github.com/kryptco/kr.git", :tag => "2.2.6"
  end

  head do
	  url "https://github.com/kryptco/kr.git"
  end

  depends_on "rust" => :build
  depends_on "go" => :build
  depends_on "pkg-config" => :build
  depends_on "libsodium"

  option "with-no-ssh-config", "DEPRECATED -- export KR_SKIP_SSH_CONFIG=1 to prevent kr from changing ~/.ssh/config"

  def install
	  ENV["GOPATH"] = buildpath
	  ENV["GOOS"] = "darwin"
	  ENV["GOARCH"] = MacOS.prefer_64_bit? ? "amd64" : "386"

	  dir = buildpath/"src/github.com/kryptco/kr"
	  dir.install buildpath.children

	  cd "src/github.com/kryptco/kr/kr" do
		  system "go", "build", "-ldflags", "-s", "-o", bin/"kr"
	  end
	  cd "src/github.com/kryptco/kr/krd/main" do
		  system "go", "build", "-ldflags", "-s", "-o", bin/"krd"
	  end
	  cd "src/github.com/kryptco/kr/krssh" do
		  system "go", "build", "-ldflags", "-s", "-o", bin/"krssh"
	  end
	  cd "src/github.com/kryptco/kr/krgpg" do
		  system "go", "build", "-ldflags", "-s", "-o", bin/"krgpg"
	  end
	  cd "src/github.com/kryptco/kr/pkcs11shim" do
		  system "make"
	  end
	  lib.install "src/github.com/kryptco/kr/pkcs11shim/target/release/kr-pkcs11.so"

	  (share/"kr").install "src/github.com/kryptco/kr/share/kr.png"
	  (share/"kr").install "src/github.com/kryptco/kr/share/co.krypt.krd.plist"

	  if ENV["KRYPTCO_CODESIGN"]
		  system "codesign", "-s", "3rd Party Mac Developer Application: KryptCo, Inc. (W7AMYM5LPN)", bin/"kr"
		  system "codesign", "-s", "3rd Party Mac Developer Application: KryptCo, Inc. (W7AMYM5LPN)", bin/"krd"
		  system "codesign", "-s", "3rd Party Mac Developer Application: KryptCo, Inc. (W7AMYM5LPN)", bin/"krssh"
		  system "codesign", "-s", "3rd Party Mac Developer Application: KryptCo, Inc. (W7AMYM5LPN)", bin/"krgpg"
	  end

  end
  
  def post_install
  end

   def caveats
	   return "kr is now installed! Run `kr pair` to pair with the Kryptonite app."
   end

end
